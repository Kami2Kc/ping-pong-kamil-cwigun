package com.example.ping.pong.kamil.cwigun.pingpong;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PingPongApplicationTests {

	@Test
	void contextLoads() {
	}

}
