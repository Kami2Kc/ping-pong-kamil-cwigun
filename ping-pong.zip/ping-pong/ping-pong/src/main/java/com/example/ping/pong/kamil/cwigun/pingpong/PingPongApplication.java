package com.example.ping.pong.kamil.cwigun.pingpong;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PingPongApplication
{
	public static void main(String[] args) {
		SpringApplication.run(PingPongApplication.class, args);
	}
}
