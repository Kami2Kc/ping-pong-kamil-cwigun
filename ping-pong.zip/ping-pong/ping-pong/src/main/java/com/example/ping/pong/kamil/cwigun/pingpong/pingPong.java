package com.example.ping.pong.kamil.cwigun.pingpong;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class pingPong
{
    @RequestMapping("/ping")
    public String returnPong()
    {
        return "Pong";
    }
}
